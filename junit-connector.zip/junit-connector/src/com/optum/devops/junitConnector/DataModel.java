package com.optum.devops.junitConnector;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author kabrret9
 * Created on 4/13/2017
 */

public class DataModel {
	
	public int debugLevel = Globals.debugLevel;
	
	public final String CREATE_TABLE_SQL =
		"CREATE TABLE `mntt01`.%s ("
			+ "id VARCHAR(100), "
			+ "name VARCHAR(150) NOT NULL, "
			+ "sonarTests FLOAT DEFAULT 0.0 NOT NULL, "
			+ "sonarErrors FLOAT DEFAULT 0.0 NOT NULL, "
			+ "sonarSkipped FLOAT DEFAULT 0.0 NOT NULL, "
			+ "sonarFailures FLOAT DEFAULT 0.0 NOT NULL, "
			+ "tests INT DEFAULT 0 NOT NULL, "
			+ "errors INT DEFAULT 0 NOT NULL, "
			+ "skipped INT DEFAULT 0 NOT NULL, "
			+ "failures INT DEFAULT 0 NOT NULL, "
			+ "DATETIME DATETIME NOT NULL );";
	
	public final String INSERT_TABLE_SQL =
			"INSERT INTO %s "
			+ "(id, name, sonarTests, sonarErrors, sonarSkipped, sonarFailures, "
			+ "tests, errors, skipped, failures, datetime) "
			+ "VALUES (\"%s\", \"%s\", %s, %s, %s, %s, %s, %s, %s, %s, \'%s\');";

	public final String SDF_MAP = "yyyy-MM-dd HH:mm:ss";

	
	// Note According to the author of the DevOPs Tableau connector, the
	// connector and the Tableau dash-board assume integer values. The data
	// from SONAR used to populate the tables however is floating point
	// with fractional values due to the computations. To not lose the
	// precision of the SONAR data while maintaining compatibility with
	// the current tableau connector code, this table will contain the
	// original decimal values AND rounded-up int values.
	
		
	String	id = "";
	String	name = "";
	Date date = null;
	
	// Original SONAR values are decimal, so record them that way
	float sonarJunitTests		= 0;
	float sonarJunitErrors		= 0;
	float sonarJunitSkipped	 	= 0;
	float sonarJunitFailures	= 0;
	
	// Tableau connect needs integers, so supply rounded-up values
	int junitTests		= 0;
	int	junitErrors		= 0;
	int	junitSkipped	= 0;
	int	junitFailures 	= 0;
	
	
	
	/*
	 * Getters and Setters
	 */
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	 
	
	/** Test Count **/
	
	public float getSonarJunitTests() {
		return sonarJunitTests;
	}

	public int getJunitTests() {
		// return Math.round(sonarJunitTests); // Base it on the original Sonar
		return junitTests;
	}

	public void setJunitTests(float tests) {
		this.sonarJunitTests = tests;
		this.junitTests = Math.round(tests);
	} // Set based on provided decimal number

	public void setJunitTests(int tests) {
		this.junitTests = tests;
		this.sonarJunitTests = tests;
	} // set based on provided integer


	/** Test Error Count **/
	
	public float getSonarJunitErrors() {
		return sonarJunitErrors;
	}

	public int getJunitErrors() {
		// return Math.round(errors_float);  // Base it on the original Sonar
		return junitErrors;
	}

	public void setJunitErrors(float errors) {
		this.sonarJunitErrors = errors;
		this.junitErrors = Math.round(errors);
	} // set based on provided decimal number

	public void setJunitErrors(int errors) {
		this.sonarJunitErrors = errors;
		this.junitErrors = errors;
	} // set based on provided int

	
	/** Tests Skipped Count **/
	
	public float getSonarJunitSkipped() {
		return sonarJunitSkipped;
	}

	public int getJunitSkipped() {
		// return Math.round(sonarJunitSkipped);  // Base it on the original Sonar
		return junitSkipped;
	}

	public void setJunitSkipped(float skipped) {
		this.sonarJunitSkipped = skipped;
		this.junitSkipped = Math.round(skipped);
	} // set based on provided on decimal number

	public void setJunitSkipped(int skipped) {
		this.junitSkipped = skipped;
		this.sonarJunitSkipped = skipped;
	} // set based on provided int

	
	/** Failure Counts **/
	
	public float getSonarJunitFailures() {
		return sonarJunitFailures;
	}

	public int getJunitFailures() {
		// return Math.round(sonarJunitFailures);  // Base it on the original Sonar
		return junitFailures;
	}

	public void setJunitFailures(float failures) {
		this.sonarJunitFailures = failures;
		this.junitFailures = Math.round(failures);
	} // set based on provided decimal number

	public void setJunitFailures(int failures) {
		this.junitFailures = failures;
		this.sonarJunitFailures = failures;
	} // set based on provided int

	
	/** Date **/
	
	public Date getDate() {
		return date;
	}
	
	public String getFormattedDate() {
		DateFormat df = new SimpleDateFormat(SDF_MAP);
		return df.format(date);
	}

	public void setDate(Date date) {
		this.date = date;
	}

//	public String getSDF() {
//		return SDF_MAP;
//	}


}
