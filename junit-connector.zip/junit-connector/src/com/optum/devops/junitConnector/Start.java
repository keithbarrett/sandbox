package com.optum.devops.junitConnector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

/**
 * @author kbarret9
 * Created 4/13/2017
 */


public class Start {
	
	private static Properties ReadPropertiesFile(String propertiesFile) {
		Properties returnStatus = null;
		
		if (propertiesFile != null) {
			if (propertiesFile != "") {
				try {
					File propFileHandle = new File(propertiesFile);
					FileInputStream fileInput = new FileInputStream(propFileHandle);
					Properties properties = new Properties();
					properties.load(fileInput);
					fileInput.close();

					returnStatus = properties;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return returnStatus;
	}

	
	public static void main(String[] args) {

		String URLfile 	 		= Globals.DFLT_URL_FILE;
		String dbServer   		= Globals.DFLT_DBSERVER;
		String dbName 	  		= Globals.DFLT_DB;
		String tableName  		= Globals.DFLT_TBLNAME;
		String dbUser 	  		= Globals.DFLT_DB_USER;
		String dbPassword 		= Globals.DFLT_DB_PW;
		String propertiesFile 	= Globals.DFLT_PROPFILE;
		
		boolean dontUpdateTable = false;	// Skip all DB Operations?
		boolean createTable		= false;	// try to create the table first?
		int count = 0;
		
		Globals.debugLevel = 0;
		int debugLevel = Globals.debugLevel;
		
		List<String> urls = new ArrayList<String>(); // Store APIs in list
		Connection con = null;
		boolean abort = false;
		BufferedReader br = null;

		System.out.printf("Junit-Connector started on %s\n", new Date().toString());

		// TODO Command line over-rides
		
		/*
		 * Load in properties file over-rides
		 */
		
		Properties keyPairs = ReadPropertiesFile(propertiesFile);
		
		if (keyPairs != null) {
			Enumeration<?> enuKeys = keyPairs.keys();

			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = keyPairs.getProperty(key);
				key = key.toLowerCase();
				
				if ((key != null) && (value != null)) {
					switch (key) {

					case "debuglevel" :
						debugLevel = Integer.valueOf(value);
						if (debugLevel > 0)
							System.out.printf("Debug: Setting debug level to %d\n", debugLevel);
						break;

					case "dontupdatetable" :
						dontUpdateTable = Boolean.valueOf(value);
						if ((debugLevel > 0) && (dontUpdateTable))
							System.out.printf("Debug: Setting dontUpdateTable\n");
						break;

					case "createtable" :
						createTable = Boolean.valueOf(value);
						if ((debugLevel > 0) && (dontUpdateTable))
							System.out.printf("Debug: Setting createTable\n");
						break;

					case "urlfile" :
						URLfile = value;
						if (debugLevel > 0)
							System.out.printf("Debug: Setting URLfile = \"%s\"\n", URLfile);
						break;

					case "dbserver" :
						dbServer = value;
						if (debugLevel > 0)
							System.out.printf("Debug: Using db Server \"%s\"\n", dbServer);
						break;

					case "database" :
						dbName = value;
						if (debugLevel > 0)
							System.out.printf("Debug: Using database \"%s\"\n", dbName);
						break;

					case "dbusername" :
						dbUser = value;
						if (debugLevel > 0)
							System.out.printf("Debug: Using db username \"%s\"\n", dbUser);
						break;

					case "dbpassword" :
						dbPassword = value;
						if (debugLevel > 0)
							System.out.printf("Debug: Setting user password\n");
						break;

					case "tablename" :
						tableName = value;
						if (debugLevel > 0)
							System.out.printf("Debug: Using table name \"%s\"\n", tableName);
						break;

					default:
						// Ignore mismatches
					}
				}
			}
		}

		
		Globals.debugLevel = debugLevel;	// set debug level for all classes

		
		/*
		 * Open URLfile and load URLs
		 */
		try {
			br = new BufferedReader(new FileReader(URLfile));
			String line = null;

			while ( ((line = br.readLine()) != null) && !abort) {
				boolean skipLine = false;
				line = line.trim();
				
				if ((line.length() == 0) || (line.startsWith("#") == true)) {
					skipLine = true;
				} // Skip blank lines and comments
				
				if (skipLine) {
					if (debugLevel > 5)
						System.out.println("Debug: Skipping comment or blank line in URL file");
				} else {
					if (debugLevel > 0)
						System.out.printf("Debug: Addding %s\n", line);
					urls.add(line);
				}
			}
		} catch (FileNotFoundException e) {			
			e.printStackTrace();
			abort = true;
		} catch (IOException e1) {
			e1.printStackTrace();
			abort = true;
		}
		

		/*
		 * Open the tableau connector database
		 */
		if (!dontUpdateTable & !abort) {
			con = DbMethods.openDB(dbServer, dbName, dbUser, dbPassword);

			if (con == null)
				abort = true;
			else {
				if (createTable) {
					DbMethods.createTable(con, tableName);
				}
			}
		}
		
		/*
		 * Loop through the URLs and read the APIs
		 */
		
		if (!abort) {
			for (String apiUrl : urls) {
				++count;
				DataModel dataObject = SonarJunitParser.getDataObject(apiUrl);

				if (!dontUpdateTable) {
					DbMethods.addToTable(con, tableName, dataObject);
				} else {
					if (debugLevel > 0)
						System.out.printf("Debug: Skipping table insert for URL #%d\n", count);
				}
			}
		}
		
		if (!abort)
			System.out.printf("\nTotal of %d records processed\n", count);
		else
			System.out.println("\nProgram aborted!\n");
	}

} // End of line
