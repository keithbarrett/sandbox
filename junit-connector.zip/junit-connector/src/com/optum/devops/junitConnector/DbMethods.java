package com.optum.devops.junitConnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DbMethods {

	private static int debugLevel = Globals.debugLevel;
	

	/**
	 * Open the tableau connector database
	 * 
	 * @param dbServer 		server designation
	 * @param dbName		database name
	 * @param dbUser		user account
	 * @param dbPassword	user password
	 * @return <connection> for subsequent DB calls
	 */
	public static Connection openDB(
			String dbServer,		// Tableau Connector Server
			String dbName,			// DB Name
			String dbUser,			// DB User Name
			String dbPassword) {	// User password
		
		Connection con = null;
		
		if ((dbServer != null) && (dbName != null) &&
			(dbUser != null) && (dbPassword != null)) {
			
			String jdbcStr = "jdbc:mysql://" + dbServer + "/" +dbName;
			if (debugLevel > 0)
				System.out.printf("Debug: About to open \"%s\"\n", jdbcStr);
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(jdbcStr, dbUser, dbPassword);
				if (debugLevel >0)
					System.out.println("Debug: Database Opened!");
				
				} catch (Exception e) {
					System.out.println(e);
			}	
		} else if (debugLevel > 0)
				System.out.println("Debug: openDB arguments must not be null");
		
		return con;
	}
	

	public static void createTable(Connection con, String tableName) {
		// Try to create table. If this fails the later inserts will report failure
		DataModel data = new DataModel();
		
		if ((tableName != null) && (data != null) && (con != null)) {
			String sqlStr = String.format(data.CREATE_TABLE_SQL, tableName);

			try {
				if (debugLevel > 0)
					System.out.printf("Debug: Attempting to create table %s...\n", tableName);
				if (debugLevel > 2)
					System.out.printf("Debug: SQL=\"%s\"\n",  sqlStr);
				
				Statement stmt = con.createStatement();		
				stmt.executeUpdate(sqlStr);
				
				if (debugLevel > 0)
					System.out.println("Debug: Table created!");

			} catch (Exception e) {
				System.out.println(e);
			}		
		} else {
			System.out.println("Null parameter passed to createTable!");
		}
	}

	
	
	
	/**
	 * Write to Table
	 * 
	 * @param con		DB connection
	 * @param tableName table name
	 * @param data		DataModel block to write
	 */
	public static void addToTable(Connection con, String tableName, DataModel data) {
		String sqlStr = null;

		if ((tableName != null) && (data != null) && (con != null)) {
			if (debugLevel > 1)
				System.out.println("Debug: Formating INSERT SQL...");

			sqlStr = String.format(data.INSERT_TABLE_SQL, 
					tableName,
					data.getId(), 
					data.getName(),
					Float.toString(data.getSonarJunitTests()), 
					Float.toString(data.getSonarJunitErrors()), 
					Float.toString(data.getSonarJunitSkipped()),
					Float.toString(data.getSonarJunitFailures()),
					Integer.toString(data.getJunitTests()),
					Integer.toString(data.getJunitErrors()),
					Integer.toString(data.getJunitSkipped()),
					Integer.toString(data.getJunitFailures()),
					data.getFormattedDate());

			try {
				if (debugLevel > 0)
					System.out.println("Debug: Inserting record into the table...");
				if (debugLevel > 2)
					System.out.printf("Debug: SQL=\"%s\"\n",  sqlStr);
				
				Statement stmt = con.createStatement();		
				stmt.executeUpdate(sqlStr);

				if (debugLevel > 1)
					System.out.println("Debug: Insert complete");

			} catch (Exception e) {
				System.out.println(e);
			}		
		} else {
			System.out.println("Null parameter passed to addToTable - no record added");
		}
	}

}
