package com.optum.devops.junitConnector;


/**
 * aAuthor kbarret9
 * Created on 4/13/2017
 */


/**
 * 
 * This class defines the global default values for variables that should be
 * over-ridden/set by the properties file and/or command line.
 * 
 */

public class Globals {
	
	/*
	 * Debug Mode
	 * 0   		= none / off 
	 * 1-5		= Levels of information;
	 * TODO 6	= include Class/method entry messages
	 * TODO 7   = include class/method entry & exit messages
	 */
	 public static int debugLevel = 0;
	 

	 /*
	 * Database information
	 */
	public final static String DFLT_DBSERVER = "10.204.98.58:3306"; // dbsrd3160.uhc.com:3306
	public final static String DFLT_DB 		 = "mntt01";
	public final static String DFLT_DB_USER  = "mntt_own";
	public final static String DFLT_DB_PW 	 = "r4y467Kv";
	//public static String app_username = "mntt_app";
	//public static String app_password = "DXX4GzTM";
	public final static String DFLT_TBLNAME	  = "junitmetrics";
	
	public final static String DFLT_PROPFILE = "junit-connector.properties";

	public final static String DFLT_URL_FILE = "JunitAPIUrls.txt";
	

}
